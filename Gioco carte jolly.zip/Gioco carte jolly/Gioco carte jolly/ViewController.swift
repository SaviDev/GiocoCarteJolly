//
//  ViewController.swift
//  Gioco carte jolly
//
//  Created by Studente on 24/11/2018.
//  Copyright © 2018 itis_barsanti. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var contatoreVittorie: UILabel!
    @IBOutlet weak var contatoreGame: UILabel!
    @IBOutlet weak var contatoreSconfitte: UILabel!
    var vittore = 0
    var game = 0
    var sconfitte = 0
    @IBOutlet weak var carta1: UIButton!
    @IBOutlet weak var carta2: UIButton!
    @IBOutlet weak var carta3: UIButton!
    @IBOutlet weak var carta4: UIButton!
    @IBOutlet weak var carta5: UIButton!
    @IBOutlet weak var carta6: UIButton!
    
    @IBOutlet weak var scopri: UIButton!
    @IBOutlet weak var rigioca: UIButton!
    @IBOutlet weak var azzera: UIButton!
    
    var n = 0
    var cartaScelta = 0
    var jolly = #imageLiteral(resourceName: "Jolly")
    var re = #imageLiteral(resourceName: "Rè 2")
    var re2 = #imageLiteral(resourceName: "Rè")
    var re3 = #imageLiteral(resourceName: "Rè 3")
    var re4 = #imageLiteral(resourceName: "Rè 4")
    var regina = #imageLiteral(resourceName: "regina")
    
    
    
    override func viewDidLoad() {
      
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        scopri.isEnabled = false
        rigioca.isEnabled = false
        rigioca.isHidden = true
        
        n = Int(arc4random()%6)
    }
    func disbilitacarte()
    {
        carta1.isEnabled = false
        carta2.isEnabled = false
        carta3.isEnabled = false
        carta4.isEnabled = false
        carta5.isEnabled = false
        carta6.isEnabled = false
    }
    @IBAction func scopricarta6(_ sender: Any) {
        cartaScelta = 6
        scopri.isEnabled = true
        if n==0
        {            carta2.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta6.setImage(re, for: .normal)
            
        }
        else if n==3
        {
           // let img2 = #imageLiteral(resourceName: "images")
            carta6.setImage(re2, for: .normal)
        }
        else if n==4
        {
            carta6.setImage(re3, for: .normal)
        }
        else if n==5
        {
            
            carta6.setImage(re4, for: .normal)
        }
        else if n==5
        {
            
            carta6.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    @IBAction func scopricarta5(_ sender: Any) {
        cartaScelta = 5
        scopri.isEnabled = true
        if n==0
        {
            carta5.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta5.setImage(re, for: .normal)
            
        }
        else if n==2
        {
            carta5.setImage(re2, for: .normal)
        }
        else if n==3
        {
            carta5.setImage(re3, for: .normal)
        }
        else if n==4
        {
            carta5.setImage(re4, for: .normal)
        }
        else if n==5
        {
            carta5.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    @IBAction func scopricarta4(_ sender: Any) {
        cartaScelta = 4
        scopri.isEnabled = true
        if n==0
        {
            carta4.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta4.setImage(re, for: .normal)
            
        }
        else if n==2
        {
            carta4.setImage(re2, for: .normal)
        }
        else if n==3
        {
            carta4.setImage(re3, for: .normal)
        }
        else if n==3
        {
            carta4.setImage(re4, for: .normal)
        }
        else if n==5
        {
            carta4.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    @IBAction func scopricarta2(_ sender: Any) {
        cartaScelta = 2
        scopri.isEnabled = true
        if n==0
        {
            carta2.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta2.setImage(re, for: .normal)
            
        }
        else if n==2
        {
            carta2.setImage(re2, for: .normal)
        }
        else if n==3
        {
            carta2.setImage(re3, for: .normal)
        }
        else if n==4
        {
            carta2.setImage(re4, for: .normal)
        }
        else if n==5
        {
            carta2.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    @IBAction func scopricarta3(_ sender: Any) {
        cartaScelta = 3
        scopri.isEnabled = true
        if n==0
        {
            carta3.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta3.setImage(re, for: .normal)
        }
        else if n==2
        {
            carta3.setImage(re2, for: .normal)
            
        }
        else if n==3
        {
            carta3.setImage(re3, for: .normal)
        }
        else if n==4
        {
            carta3.setImage(re4, for: .normal)
        }
        else if n==5
        {
            carta3.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    
    @IBAction func scopricarta1(_ sender: Any) {
        cartaScelta = 1
        scopri.isEnabled = true
        if n==0
        {
            carta1.setImage(jolly, for: .normal)
        }
        else if n==1
        {
            carta1.setImage(re, for: .normal)
        }
        else if n==2
        {
            carta1.setImage(re2, for: .normal)
        }
        else if n==3
        {
            carta1.setImage(re3, for: .normal)
        }
        else if n==4
        {
            carta1.setImage(re4, for: .normal)
        }
        else if n==5
        {
            carta1.setImage(regina, for: .normal)
        }
        disbilitacarte()
    }
    
   @IBAction func scoperto(_ sender: Any) {
        
        if cartaScelta == 1
        {
            if n == 0
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-1")
                carta2.setImage(#imageLiteral(resourceName: "download"), for: .normal)
                carta3.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
            }
            else if n == 1
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta3.setImage(#imageLiteral(resourceName: "images"), for: .normal)
                carta2.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
            }
            else if n == 2
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta2.setImage(#imageLiteral(resourceName: "images"), for: .normal)
                carta3.setImage(#imageLiteral(resourceName: "download"), for: .normal)
            }
        }
        else if cartaScelta == 2
        {
            if n == 2
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-1")
                carta1.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
                carta3.setImage(#imageLiteral(resourceName: "download"), for: .normal)
            }
            else if n == 0
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta3.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
                carta1.setImage(#imageLiteral(resourceName: "images"), for: .normal)
            }
            else
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta1.setImage(#imageLiteral(resourceName: "download"), for: .normal)
                carta3.setImage(#imageLiteral(resourceName: "images"), for: .normal)
            }
        }
        else if cartaScelta == 3
        {
            if n == 1
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-1")
                carta1.setImage(#imageLiteral(resourceName: "download"), for: .normal)
                carta2.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
            }
            else if n == 0
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta1.setImage(#imageLiteral(resourceName: "images"), for: .normal)
                carta2.setImage(#imageLiteral(resourceName: "download"), for: .normal)
            }
            else
            {
                immagine.isHidden = false
                immagine.image = #imageLiteral(resourceName: "download-2")
                carta1.setImage(#imageLiteral(resourceName: "download-3"), for: .normal)
                carta2.setImage(#imageLiteral(resourceName: "images"), for: .normal)
            }
        }
        rigioca.isEnabled = true
        rigioca.isHidden = false
        scopri.isHidden = true
        scopri.isEnabled = false
    }
    @IBAction func rigioca(_ sender: Any) {
        scopri.isHidden = false
        rigioca.isHidden = true
        rigioca.isEnabled = false
        carta1.setImage(#imageLiteral(resourceName: "images-1"), for: .normal)
        carta2.setImage(#imageLiteral(resourceName: "images-1"), for: .normal)
        carta3.setImage(#imageLiteral(resourceName: "images-1"), for: .normal)
        immagine.isHidden = true
        scopri.isEnabled = true
        carta1.isEnabled = true
        carta2.isEnabled = true
        carta3.isEnabled = true
        n = Int(arc4random()%3)
        cartaScelta = 0    }



}
 
